import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import Select from 'react-select';
import { Link } from 'react-router-dom';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';

// List of Eswatini Premier League Teams
const ESWATINI_TEAMS = [
  { value: 'mbabane_swallows', label: 'Mbabane Swallows' },
  { value: 'mbabane_highlanders', label: 'Mbabane Highlanders' },
  { value: 'manzini_wanderers', label: 'Manzini Wanderers' },
  { value: 'green_mamba', label: 'Green Mamba' },
  { value: 'young_buffaloes', label: 'Young Buffaloes' },
  { value: 'royal_leopards', label: 'Royal Leopards' },
  { value: 'nsingizini_hotspurs', label: 'Nsingizini Hotspurs' },
  { value: 'moneni_pirates', label: 'Moneni Pirates' },
  { value: 'tambuti_fc', label: 'Tambuti FC' },
  { value: 'madlenya_fc', label: 'Madlenya FC' },
];

const schema = z.object({
  tournament: z.string().min(1, 'Tournament name is required'),
  officerName: z.string().min(1, 'Officer name is required'),
  date: z.string().min(1, 'Date is required'),
  homeTeam: z.string().min(1, 'Home team is required'),
  awayTeam: z.string().min(1, 'Away team is required'),
  venue: z.string().min(1, 'Venue is required'),
  league: z.string().min(1, 'League is required'),
  stadium: z.string().min(1, 'Stadium is required'),
  expectedAttendance: z.number().min(0, 'Attendance must be 0 or more'),
  venueMeeting: z.string().min(1, 'Required'),
  stewardsBriefing: z.string().min(1, 'Required'),
  redLinePrecinct: z.string().min(1, 'Required'),
  matchCoordination: z.string().min(1, 'Required'),
  teamTrainings: z.string().min(1, 'Required'),
  pressConferences: z.string().min(1, 'Required'),
  locCooperation: z.string().min(1, 'Required'),
  vocCommanderCooperation: z.string().min(1, 'Required'),
  stadiumAuthorityCooperation: z.string().min(1, 'Required'),
  pleDelegationCooperation: z.string().min(1, 'Required'),
  overallEvaluation: z.string().min(1, 'Required'),
  issuesDescription: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function MatchDayMinus1Report() {
 /* 
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      officerName: 'Colani Dlamini', // TODO: from auth later
      date: new Date().toISOString().split('T')[0],
      expectedAttendance: 0,
    },
  });
*/
  const { register, handleSubmit, control, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      officerName: 'Colani Dlamini',
      date: new Date().toISOString().split('T')[0],
      expectedAttendance: 0,
    },
  });

  const onSubmit = async (data: FormData) => {
  console.log('Form data being submitted:', data); // Your console log is here

  if (!auth.currentUser) {
    alert("You must be logged in to submit.");
    return;
  }

  try {
    // We create a unique ID based on teams and date
    const reportId = `${data.homeTeam}-vs-${data.awayTeam}-${data.date}`;
    
    await setDoc(doc(db, 'matches', reportId), {
      ...data,
      officerEmail: auth.currentUser.email,
      submittedAt: serverTimestamp(),
      status: 'submitted'
    });

    alert('Successfully saved to EFA Database!');
  } catch (error) {
    console.error('Firebase Error:', error);
    alert('Error saving data. Check console.');
  }
};

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-blue-100">
        {/* Header with EFA branding */}
        <div className="bg-gradient-to-r from-blue-800 to-blue-950 py-8 px-10 text-white text-center">
          <div className="flex justify-center mb-4">
            {/* Replace with real logo */}
            <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-lg">
              <span className="text-4xl font-bold text-blue-800">EFA</span>
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
            MATCH DAY -1 REPORT
          </h1>
          <p className="mt-2 text-blue-200 text-lg">
            Pre-Match Security Assessment
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="p-8 md:p-12">
          {/* Basic Info - Table-like */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name of the Tournament
              </label>
              <input
                {...register('tournament')}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 text-black placeholder:text-gray-400"
                placeholder="Enter tournament name"
              />
              {errors.tournament && <p className="text-red-600 text-sm mt-1">{errors.tournament.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name of Safety and Security Officer
              </label>
              <input
                {...register('officerName')}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 text-black placeholder:text-gray-400 bg-gray-100"
                disabled // Auto-filled later
              />
            </div>

{/* Date Field - Native HTML5 Calendar */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
          <input
            type="date"
            {...register('date')}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 text-black"
          />
        </div>

        {/* Home Team Searchable Dropdown */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">Home Team</label>
          
          <Controller
            name="homeTeam"
            control={control}
            render={({ field }) => (
              <Select
                {...field}
                options={ESWATINI_TEAMS}
                placeholder="Search or select home team..."
                onChange={(val) => field.onChange(val?.value)}
                value={ESWATINI_TEAMS.find(c => c.value === field.value)}
                styles={{
                  control: (base) => ({ ...base, padding: '4px' }),
                  option: (base, state) => ({
                    ...base,
                    color: 'black', // Ensures dropdown options are black
                    backgroundColor: state.isFocused ? '#EFF6FF' : 'white', // Light blue hover
                  }),
                  singleValue: (base) => ({ ...base, color: 'black' }), // Ensures selected text is black
                }}
              
              />
            )}
          />
          
          {errors.homeTeam && <p className="text-red-600 text-sm">{errors.homeTeam.message}</p>}
        </div>

        {/* Away Team Searchable Dropdown */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">Away Team</label>
          <Controller
            name="awayTeam"
            control={control}
            render={({ field }) => (
              <Select
                {...field}
                options={ESWATINI_TEAMS}
                placeholder="Search or select away team..."
                onChange={(val) => field.onChange(val?.value)}
                value={ESWATINI_TEAMS.find(c => c.value === field.value)}
                styles={{
                  control: (base) => ({ ...base, padding: '4px' }),
                  option: (base, state) => ({
                    ...base,
                    color: 'black', // Ensures dropdown options are black
                    backgroundColor: state.isFocused ? '#EFF6FF' : 'white', // Light blue hover
                  }),
                  singleValue: (base) => ({ ...base, color: 'black' }), // Ensures selected text is black
                }}
              />
            )}
          />
          {errors.awayTeam && <p className="text-red-600 text-sm">{errors.awayTeam.message}</p>}
        </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Venue / League / Stadium</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <input
                  {...register('venue')}
                  placeholder="Venue"
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 text-black placeholder:text-gray-400"
                />
                <input
                  {...register('league')}
                  placeholder="League"
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 text-black placeholder:text-gray-400"
                />
                <input
                  {...register('stadium')}
                  placeholder="Stadium"
                  className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 text-black placeholder:text-gray-400"
                />
              </div>
            </div>
          </div>

          {/* Expected Attendance */}
          <div className="mb-10">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Expected Stadium Attendance (Give a Number)
            </label>
            <input
              type="number"
              {...register('expectedAttendance', { valueAsNumber: true })}
              className="w-full sm:w-1/3 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 text-black placeholder:text-gray-400"
              placeholder="e.g. 15000"
            />
            {errors.expectedAttendance && (
              <p className="text-red-600 text-sm mt-1">{errors.expectedAttendance.message}</p>
            )}
          </div>

          {/* Questions - Table-like grid */}
          <div className="space-y-8">
            {[
              { label: 'How was the venue Safety and Security meeting? Explain briefly.', field: 'venueMeeting' },
              { label: 'How was the briefing of the stewards’ supervisors? Explain briefly.', field: 'stewardsBriefing' },
              { label: 'How is the red-line precinct? Explain briefly.', field: 'redLinePrecinct' },
              { label: 'How was the match coordination meeting? Explain briefly.', field: 'matchCoordination' },
              { label: 'How were the official team trainings? Explain briefly.', field: 'teamTrainings' },
              { label: 'How were the press conferences? Explain briefly.', field: 'pressConferences' },
              { label: 'How was the cooperation and team work with LOC counterparts? Explain briefly.', field: 'locCooperation' },
              { label: 'How was the cooperation and team work with the Venue Operations Centre Commander? Explain briefly.', field: 'vocCommanderCooperation' },
              { label: 'How was the cooperation and teamwork with the stadium authority? Explain briefly.', field: 'stadiumAuthorityCooperation' },
              { label: 'How was the cooperation and teamwork with the PLE delegation? Explain briefly.', field: 'pleDelegationCooperation' },
              { label: 'What is your overall evaluation? Explain briefly.', field: 'overallEvaluation' },
            ].map((item) => (
              <div key={item.field} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
                <label className="md:col-span-2 text-sm font-medium text-gray-700">
                  {item.label}
                </label>
                <textarea
                  {...register(item.field as keyof FormData)}
                  rows={3}
                  className="md:col-span-1 w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-200 text-black placeholder:text-gray-400 resize-y min-h-[80px]"
                  placeholder="Explain briefly..."
                />
                {errors[item.field as keyof FormData] && (
                  <p className="md:col-span-3 text-red-600 text-sm mt-1">
                    {errors[item.field as keyof FormData]?.message}
                  </p>
                )}
              </div>
            ))}

            {/* Issues Section */}
            <div className="mt-12">
              <label className="block text-lg font-semibold text-gray-800 mb-3">
                If there were any issues/concerns, please provide a description and evaluation of the resolution for each of the issues.
              </label>
              <textarea
                {...register('issuesDescription')}
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-200 text-black placeholder:text-gray-400 resize-y"
                placeholder="Describe any issues and how they were resolved..."
              />
            </div>
          </div>

          {/* Buttons */}
          <div className="mt-12 flex flex-col sm:flex-row gap-6 justify-end">
            <button
              type="button"
              className="px-8 py-4 bg-gray-600 text-white rounded-xl hover:bg-gray-700 transition"
              onClick={() => alert('Draft saved! (Demo)')}
            >
              Save as Draft
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`px-10 py-4 text-white font-semibold rounded-xl transition shadow-md
                ${isSubmitting ? 'bg-green-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700'}`}
            >
              {isSubmitting ? 'Submitting...' : 'Submit Report'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

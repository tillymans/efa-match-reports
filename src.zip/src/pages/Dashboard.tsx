import { Link } from 'react-router-dom';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Welcome Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-blue-900 mb-4">
            Welcome back, Officer
          </h1>
          <p className="text-xl text-gray-700">
            Manage your match reports here
          </p>
        </div>

        {/* New Report Button */}
        <div className="text-center mb-16 ">
          <Link
            to="/match-day-minus1" // This matchday-1 page
            className="inline-flex items-center px-10 py-5 bg-green-600 text-xl font-bold rounded-xl hover:bg-green-700 transition duration-300 shadow-lg hover:shadow-xl  text-black"
          >
            + Start New Match Report
          </Link>
        </div>

        {/* Placeholder for future reports list */}
        <div className="bg-white rounded-2xl shadow-xl p-10 text-center">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6">
            Your Recent Reports
          </h2>
          <p className="text-gray-600 text-lg">
            No reports submitted yet. Start your first one above.
          </p>
        </div>
      </div>
    </div>
  );
}
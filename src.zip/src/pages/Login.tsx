import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Demo simulation - replace later with Firebase
    setTimeout(() => {
      setIsLoading(false);
      alert('Login successful! (Demo)');
      navigate('/dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-gray-50 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl overflow-hidden border border-blue-100">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-800 to-blue-950 py-10 px-8 text-center">
          <div className="flex justify-center mb-4">
            {/* Use your downloaded logo */}
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg">
              <span className="text-3xl font-bold text-blue-800">EFA</span>
              {/* <img src="/efa-logo.png" alt="EFA Logo" className="w-16 h-16 object-contain" /> */}
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white tracking-tight">
            EFA Security Portal
          </h2>
          <p className="mt-2 text-blue-200 text-sm">
            Login to submit your match reports
          </p>
        </div>

        {/* Form - fixed text colors */}
        <form onSubmit={handleSubmit} className="px-8 py-10">
          <div className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-200 text-black placeholder:text-gray-400"
                placeholder="your.name@efa.sz"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-200 text-black placeholder:text-gray-400"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-4 px-6 text-white font-semibold rounded-xl transition duration-300 shadow-md
                ${isLoading ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-700 hover:bg-blue-800 active:bg-blue-900'}`}
            >
              {isLoading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin h-5 w-5 mr-3 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8h8z" />
                  </svg>
                  Logging in...
                </span>
              ) : (
                'Login'
              )}
            </button>
          </div>

          <div className="mt-8 text-center text-sm">
            <a href="#" className="text-blue-600 hover:text-blue-800 hover:underline">
              Forgot password?
            </a>
            <p className="mt-4 text-gray-600">
              Don't have an account?{' '}
              <Link to="/register" className="text-blue-700 font-medium hover:underline">
                Register here
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}
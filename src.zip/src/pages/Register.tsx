import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Register() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Placeholder for real Firebase registration later
    setTimeout(() => {
      setIsLoading(false);
      alert('Registration successful! (Demo mode)\nWelcome, ' + fullName);
      navigate('/dashboard');
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-gray-50 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl overflow-hidden border border-blue-100">
        {/* Header / Branding */}
        <div className="bg-gradient-to-r from-blue-800 to-blue-950 py-10 px-8 text-center">
          <div className="flex justify-center mb-4">
            {/* Replace with real logo when you add it */}
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg">
              <img src="/efa_logo.png" alt="EFA Logo" className="w-16 h-16 object-contain" />
              {/* <img src="/efa-logo.png" alt="EFA Logo" className="w-16 h-16 object-contain" /> */}
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white tracking-tight">
            Create EFA Account
          </h2>
          <p className="mt-2 text-blue-200 text-sm">
            Register as a Security Officer
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="px-8 py-10">
          <div className="space-y-6">
            {/* Full Name */}
            <div>
              <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                Full Name
              </label>
              <input
                id="fullName"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-200  text-black placeholder:text-gray-400"
                placeholder="Name Surname"
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-200  text-black placeholder:text-gray-400"
                placeholder="your@email.com"
              />
            </div>

            {/* Password */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition duration-200  text-black placeholder:text-gray-400"
                placeholder="••••••••"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-4 px-6 text-white font-semibold rounded-xl transition duration-300 shadow-md
                ${isLoading 
                  ? 'bg-blue-400 cursor-not-allowed' 
                  : 'bg-blue-700 hover:bg-blue-800 active:bg-blue-900'
                }`}
            >
              {isLoading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin h-5 w-5 mr-3 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8h8z" />
                  </svg>
                  Creating account...
                </span>
              ) : (
                'Register'
              )}
            </button>
          </div>

          {/* Links */}
          <div className="mt-8 text-center text-sm">
            <p className="text-gray-600">
              Already have an account?{' '}
              <Link to="/login" className="text-blue-700 font-medium hover:underline">
                Login here
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}